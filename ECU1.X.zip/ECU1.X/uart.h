/* 
 * File:   uart.h
 * Author: prana
 *
 * Created on 9 March, 2026, 11:54 AM
 */

#ifndef UART_H
#define	UART_H

void init_uart(void);
void putchar(unsigned char data);
unsigned char getchar();
void puts(unsigned char*data);

#endif	/* UART_H */

