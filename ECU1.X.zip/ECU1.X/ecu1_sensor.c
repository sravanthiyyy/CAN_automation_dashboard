/*
 * File:   ecu1_sensor.c
 * Author: prana
 *
 * Created on 25 February, 2026, 8:43 AM
 */

#include "ecu1_sensor.h"
#include "adc.h"
#include "clcd.h"
#include "matrix_keypad.h"
#include "can.h"
#include "msg_id.h"
#include "uart.h"

unsigned char gear[8][3] = {"G1","G2","G3","G4","G5","RE","NU","CO"};

uint16_t get_speed()
{
    // Implement the speed function
    unsigned int adc_value = read_adc(CHANNEL4);
    
    uint16_t result = ((uint32_t)adc_value * 99U) / 1023U;
    
    uint8_t data[2];
            
    data[0] = (result/10)+'0'; //tens
    data[1] = (result%10)+'0'; //ones
    
    can_transmit(SPEED_MSG_ID,data,2);
   
    return result;
    
}

unsigned char get_gear_pos()
{
    // Implement the gear function
    
    static unsigned char gear_index = 6;
    static unsigned char prev_index = 6;
    
    unsigned char key = read_matrix_keypad(EDGE);
    
        if(key == SW1)
        {
            if(gear_index == 6)
                gear_index = 0;
            else if(gear_index <= 5)
                gear_index++;
           
        }
        else if(key == SW2)
        {
            if(gear_index == 0)
                gear_index = 6;
            else if(gear_index <= 5)
                gear_index--;
        }
        if(key == SW3)
        {
            gear_index = 7;
        }
        else if(key == SW1 || key == SW2)
        {
            if(gear_index == 7)
            gear_index = 6;   // exit collision first
        }
    if(gear_index != prev_index)
    {
    
        uint8_t data[1];
        data[0] = gear_index;

        can_transmit(GEAR_MSG_ID,data,1);
        prev_index = gear_index;
    }

    return gear_index;
}
