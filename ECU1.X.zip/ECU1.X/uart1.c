/*
 * File:   uart1.c
 * Author: prana
 *
 * Created on 9 March, 2026, 11:53 AM
 */


#include <xc.h>
#include "uart.h"

void init_uart(void)
{
    TRISC6 = 0;   //OP
    TRISC7 = 1;   //IP
    
    
    //TXSTA CONTROL REGISTER
    TXEN = 1;    //TRANSMIT ENABLE BIT
    
    SYNC = 0;   //ASYNCHRONOUS MODE
    
    BRGH = 1;   //HIGH SPEED
    
    TX9 = 0;   //NO PARITY
    
    SENDB = 0;  //DISABLE BREAK CHARACTER BIT
    
    
    //RCSTA CONTROL REGISTER
    SPEN = 1;   //SERIAL PORT ENABLE
    
    RX9 = 0;    //8 BIT RECEPTION
    
    CREN = 1;   //ENABLE CONTINUOUS RECEPTION
    
    
    //BAUDCON CONTROL REGISTER
    ABDOVF = 1;  //NO OVERFLOW DETECT
    
    BRG16 = 0;   //8 BIT BAUD RATE
    
    WUE = 0;    //DISABLE WAKE UP
    
    ABDEN = 0;   //AUTO BAUD RATE DETECT DISBALE
    
    SPBRG = 129;  //SETTING BAUD RATE AS 9600
    
    TXIF = 0;
    
    RCIF = 0;
}

void putchar(unsigned char data)
{
    while(!TXIF);       //txreg empty then txif is 1 else 0
    
    TXREG = data;
}

unsigned char getchar()
{
    while(!RCIF);    //WAIT UNTIL DATA IS LOADED
    
    return RCREG;
    
}

void puts(unsigned char*data)
{
    while(*data != '\0')
    {
        putchar(*data);
        data++;
    }
}

