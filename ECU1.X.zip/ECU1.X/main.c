/*
 * File:   main.c
 * Author: prana
 *
 * Created on 25 February, 2026, 8:41 AM
 */

#include "adc.h"
#include "can.h"
#include "ecu1_sensor.h"
#include "msg_id.h"
#include "clcd.h"
#include "matrix_keypad.h"
#include "uart.h"

#define _XTAL_FREQ 20000000 

void init_config()
{
    init_adc();
    init_clcd();
    init_matrix_keypad();
    init_can();
    init_uart();
}
unsigned char gear[8][3] = {"G1","G2","G3","G4","G5","RE","NU","CO"};
int main()
{
    init_config();

    uint16_t speed;
    unsigned char gear_pos;
    
    uint16_t msg_id;
    unsigned char data[3];
    unsigned char len;

    
    while(1)                                                                   
    {
        //SPEED
        get_speed();
        __delay_ms(50);

//        can_receive(&msg_id, data, &len);
//
//
//
//        if (msg_id == SPEED_MSG_ID) {
//            data[len] = '\0';
//            puts("SPEED:");
//            puts((char*) data);
//            puts("\n\r");
//
//        }
//        
//        
           get_gear_pos();
            __delay_ms(50);
//        can_receive(&msg_id, data, &len);
//        if (msg_id == GEAR_MSG_ID) {
//            puts("GEAR:");
//            puts(gear[data[0]]);
//            puts("\n\r");
//        }
       
        
        /*str[0] = (speed/10)+'0';
        str[1] = (speed%10)+'0';
        str[2] = '\0';
        
        clcd_print("SPEED:",LINE1(0));
        clcd_print(str,LINE1(7))bg;*/
        
//        can_receive(&msg_id, data, &len);
//        
//        if(len>0)
//        {
//            if(msg_id == SPEED_MSG_ID)
//            {
//                data[len] = '\0';
//                clcd_print("SPEED:",LINE1(0));
//                clcd_print(data,LINE1(7));
//            }  
//            if(msg_id == GEAR_MSG_ID)
//            {
//                clcd_print("GEAR POS:",LINE2(0));
//                clcd_print(gear[data[0]],LINE2(9));
//            } 
//        }
   
        
        /*clcd_print("GEAR POS:",LINE2(0));
        clcd_print("    ",LINE2(11));
        clcd_print(gear[gear_pos],LINE2(9));*/
    }
}
