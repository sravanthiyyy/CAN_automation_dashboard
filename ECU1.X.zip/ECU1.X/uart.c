/*
 * File:   uart.c
 * Author: prana
 *
 * Created on 9 March, 2026, 11:49 AM
 */


#include <xc.h>

void main(void) {
    return;
}
