/*
 * File:   ecu2_sensor.c
 * Author: prana
 *
 * Created on 26 February, 2026, 6:18 PM
 */


#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
//#include "uart.h"
#include "ssd.h"
#include "matrix_keypad.h"
#include "clcd1.h"


uint16_t get_rpm()
{
    //Implement the rpm function
   
    unsigned int adc_value = read_adc(CHANNEL4);

    uint32_t temp = (uint32_t)adc_value * 6000U;
    uint16_t rpm = temp / 1023U;
    
    uint8_t data[5];
    
    data[3] = (rpm%10)+'0';
    data[2] = ((rpm/10)%10)+'0';
    data[1] = ((rpm/100)%10)+'0';
    data[0] = (rpm/1000)+'0';
    //clcd_print("Transmit",LINE1(0));
    can_transmit(RPM_MSG_ID,data,4);
    return rpm;
    
}

uint16_t get_engine_temp()
{
    //Implement the engine temperature function
    uint16_t temp_value = read_adc(CHANNEL6);
    
    uint16_t temp = (uint16_t)(((uint32_t)temp_value * 500U) / 1023U);
    
    uint8_t data[2];
    
    data[0] = (temp/10)+'0';
    data[1] = (temp%10)+'0';
    
    //can_transmit(ENG_TEMP_MSG_ID,data,2);
    
    return temp;
}

IndicatorStatus process_indicator()
{
    //Implement the indicator function
    static IndicatorStatus state = e_ind_off;
    unsigned char key = read_matrix_keypad(EDGE);
    
    if(key == SW1)
    {
        state = e_ind_left;      //STATE IS ACTUALLY INTEGER 0,1,2,3
    }
    else if(key == SW2)
    {
        state = e_ind_right;
    }
    else if(key == SW3)
    {
        state = e_ind_hazard;
    }
    else if(key == SW4)
    {
        state = e_ind_off;
    }
    
    uint8_t data[1];
    data[0] = state;
    
    can_transmit(INDICATOR_MSG_ID,data,1);
    return state;
}
