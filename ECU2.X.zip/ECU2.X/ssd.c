/*
 * File:   ssd.c
 * Author: prana
 *
 * Created on 26 February, 2026, 6:49 PM
 */


#include <xc.h>
#include "ssd.h"

void init_ssd(void) {
    //Setting control pins as output
    CONTROL_PORT_DDR = CONTROL_PORT_DDR & 0XF0;

    //Setting data pins as output
    DATA_PORT_DDR = 0X00;

    //Initializing control pins
    CONTROL_PORT = CONTROL_PORT & 0XF0; //ssd are off
}

void display(unsigned char* SSD) {
    
    for (int i = 0; i < 4; i++) //4 variables i j k l
    {
        DATA_PORT = SSD[i];
        CONTROL_PORT = (CONTROL_PORT & 0XF0) | (1 << i);
        for (int wait = 1000; wait--;);
    }
}

