/*
 * File:   clcd.c
 * Author: prana
 *
 * Created on 26 February, 2026, 6:42 PM
 */


#include <xc.h>

void main(void) {
    return;
}
