/* 
 * File:   clcd.h
 * Author: prana
 *
 * Created on 26 February, 2026, 6:42 PM
 */

#ifndef CLCD_H
#define	CLCD_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* CLCD_H */

