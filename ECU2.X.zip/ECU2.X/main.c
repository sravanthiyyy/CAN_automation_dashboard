/*
 * File:   main.c
 * Author: prana
 *
 * Created on 26 February, 2026, 6:20 PM
 */


#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
//#include "uart.h"
#include "ssd.h"
#include "matrix_keypad.h"
#include "clcd1.h"

#define _XTAL_FREQ 20000000 

unsigned char digit[] ={0xE7,0x21,0xCB,0x6B,0x2D,0x6E,0xEE,0x23,0xEF,0x6F};
unsigned char ssd[4];

void init_config()
{
    //TRISB = 0X00;    //LEDS OUTPUT
    //PORTB = 0X00;
    
    init_adc();
    init_ssd();
    init_can();
    init_matrix_keypad();
    init_clcd();
}

int main()
{
    init_config();
    IndicatorStatus status;
    uint16_t rpm, temp;
    
    
    uint16_t msg_id;
    unsigned char data[8];
    unsigned char len;

    
    while(1)
    {
        
       //call the functions
       //GET RPM FUNCTION
        get_rpm();
      __delay_ms(50);
    
       /*ssd[0]=digit[rpm/1000];
       ssd[1]=digit[(rpm/100)%10];
       ssd[2]=digit[(rpm/10)%10];
       ssd[3]=digit[rpm%10];
    
       display(ssd);*/ 
       
       
       //GET TEMPERATURE FUNCTION
       //temp = get_engine_temp();
       
       /*ssd[0] = digit[temp / 1000];   // usually 0
       ssd[1] = digit[(temp / 100) % 10];
       ssd[2] = digit[(temp / 10) % 10];
       ssd[3] = digit[temp % 10];
       display(ssd);*/
       
       //PROCESS INDICATOR FUNCTION normal clcd
       process_indicator();
      __delay_ms(50);
//       switch(status)
//       {
//           case e_ind_left:
//               clcd_putch('L',LINE1(0));   //LEFT 2 LEDS
//               break;
//               
//           case e_ind_right:
//               clcd_putch('R',LINE1(0));   //RIGHT 2 LEDS
//               break;
//               
//           case e_ind_hazard:
//               clcd_putch('H',LINE1(0));    //BOTH SIDES
//               break;
//               
//           case e_ind_off:
//               clcd_putch('O',LINE1(0));    //ALL OFF
//               break;
//       }
//       can_receive(&msg_id, data, &len);
//       if(len>0)
//       {
//          if(msg_id == RPM_MSG_ID)
//          {
//             ssd[0] = digit[data[0]-'0'];
//             ssd[1] = digit[data[1]-'0'];
//             ssd[2] = digit[data[2]-'0'];
//             ssd[3] = digit[data[3]-'0'];
//          }
//          display(ssd);
//          
//          if(msg_id == INDICATOR_MSG_ID)
//          {
//               status = data[0];
//
//               switch(status)
//               {
//                    case e_ind_left:
//                    clcd_putch('L',LINE1(0));   //LEFT 2 LEDS
//                    break;
//
//                    case e_ind_right:
//                    clcd_putch('R',LINE1(0));   //RIGHT 2 LEDS
//                    break;
//
//                    case e_ind_hazard:
//                    clcd_putch('H',LINE1(0));    //BOTH SIDES
//                    break;
//
//                    case e_ind_off:
//                    clcd_putch('O',LINE1(0));    //ALL OFF
//                    break;
//                }
//          }
//        }
    }
}