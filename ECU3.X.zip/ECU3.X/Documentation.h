/* 
 * File:   Documentation.h
 * Author: prana
 *
 * Created on 18 March, 2026, 11:47 AM
 */

#ifndef DOCUMENTATION_H
#define	DOCUMENTATION_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* DOCUMENTATION_H */

